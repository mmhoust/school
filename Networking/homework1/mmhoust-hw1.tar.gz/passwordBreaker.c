// Matthew Houston//
// Cpsc360 //
/* This program will attempt to break the password by sending every valid password combination 
   to the password server and waiting for the response. If it timesout or is a failure it will
   iterate to the next valid password and try again looping back to the beginning if necessary.
   Upon completion or interuption the program will print out the number of guesses and time ran */

#include "passwordBreaker.h"
#include <signal.h>
// global variables to allow signal handler to print times attempted and time ran 
int timesAttempted;
double t; // time 

int main(int argc, char*argv[]){
	int sock;

	struct addrinfo hints;
        struct addrinfo *result;
	char* servPort;
	char* servName;
	int passwordSize;
	
	uint8_t returnCode; // 0 = success 1 = failure 2 = timeout
	double t;
	char guess[10]; // max password size is 10
	t = getTime();
	signal(SIGINT,handleInterupt);

	servPort = argv[2];
	servName = argv[1];
	passwordSize = atoi(argv[3]);
	
	//printf("passwordsize = %d\n",passwordSize);
	// get initial password
	int i;
	for(i = 0; i < passwordSize; ++i){
		strcat(guess,"0");
	}
	
	memset(&hints, 0, sizeof(struct addrinfo));
        hints.ai_family = AF_UNSPEC;    /* Allow IPv4 or IPv6 */
        hints.ai_socktype = SOCK_DGRAM; /* Datagram socket */
        hints.ai_flags = 0;
        hints.ai_protocol = 0;

        if(getaddrinfo(servName, servPort, &hints, &result) != 0)
		err_n_die("Could not resolve IP address \n");

  	if ((sock = socket(result->ai_family, SOCK_DGRAM, IPPROTO_UDP)) < 0)
      		err_n_die("could not create socket \n");

	returnCode = tryPassword(guess, passwordSize, *result->ai_addr,sock);
	timesAttempted = 1;
	while(returnCode != 0){
		getNextPassword(guess,passwordSize,passwordSize);
		returnCode = tryPassword(guess, passwordSize, *result->ai_addr,sock);	
		//printf("Code %s is a %d \n",guess,returnCode);
		timesAttempted++;	
	}

	freeaddrinfo(result);
	t = getTime() - t;
	printf("Password Cracked.\n Password = %s \n took %d tries and %f seconds\n"
		,guess,timesAttempted,t);
	return 0;
}
// this program trys to send the password and waits for the response and returns the response code. Upon
// timeout the response code is set to 2 for timeout.
uint8_t tryPassword(char* guess, int n, struct sockaddr addr,int sock){
	int bytesSent, bytesRecieved;
	uint8_t returnCode;
	socklen_t sizeOfAddr = sizeof(addr);
	// set timeouts
	struct timeval tv;
	tv.tv_sec = 1;
	tv.tv_usec = 0;
	// set send and recieve timeouts i didn't use signals because i can do this and its easier.
	if(setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO,&tv,sizeof(tv)) <0){
		err_n_die("Could not set timeout");
	}
	if(setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO,&tv,sizeof(tv)) <0){
		err_n_die("Could not set timeout");
	}
	if((bytesSent = sendto(sock,guess,n+1,0, &addr, sizeOfAddr)<0)){
		returnCode = 2; // set return code to timeout
		printf("Timeout\n");
	}
	if((bytesRecieved = recvfrom(sock,&returnCode,1,0,
		 &addr, &sizeOfAddr)< 0)){
		returnCode = 2; // set return code to timeout
		printf("Timeout\n");
	}

	return returnCode;
}
// This function uses recursion to iterate through each valid password, if the rightmost
// character is z the function changes the character one place to the left up 1 and resets 
// the rightmost to zero. this is true for all characters in the string. Upon reaching the
// final valid string it resets to 00.. and starts again.
void getNextPassword(char* password, int depth, int n){
	if(depth == 0){
		return;
	}
	// if end of range i.e 0-9 jump to next range
	if(password[depth-1] == '9'){
		password[depth-1] = 'A';
		return;
	}else if(password[depth-1] == 'Z'){
		password[depth-1] = 'a';
		return;
	}else if(password[depth-1] == 'z'){
		// get when one letter has iterated through ah nevermind idk how to explain what
		// i did it works though
		getNextPassword(password,depth-1,n);
		int i;
		for(i = depth -1; i<n; ++i){
			password[i] = '0';
		}
		return;
	}else {
		password[depth-1] += 1;
		return;
	}
}
// this function returns time in seconds
double getTime(){
	struct timeval curTime;
	gettimeofday(&curTime,NULL);
	double ret;
	ret = (curTime.tv_sec * 1000000 + curTime.tv_usec) / 1000000.0;
	return ret;
}


// prints out the amount of guesses and is supposed to print out time. 
// time gets wiped before entering so it just prints current time.
void handleInterupt(int signum){
	printf("%f \n ",getTime());
	t = getTime() - t;
	printf("Program terminated \n Guessed %d times and ran for %f seconds \n"
		,timesAttempted,t);
	exit(1);
}
	


