//Matthew Houston//
//cpsc360 //
// This module contains the err_n_die method along with all of the networking
// includes in the .h file. It will eventually be expanded to have other functions 
// that i will commonly use in networking i.e. error checking wrapper functions

#include "methods.h"

// This method prints out an error message and quits the program.
void err_n_die(const char* msg){
	perror(msg);
	exit(1);
}
